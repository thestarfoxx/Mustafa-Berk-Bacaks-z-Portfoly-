import turtle
import math
import random
import winsound

wn = turtle.Screen()
wn.setup(800, 800)
wn.bgcolor("black")
wn.bgpic()

bpen = turtle.Turtle()
bpen.hideturtle()
bpen.speed(0)
bpen.color("white")
bpen.penup()
bpen.setposition(-300, -300)
bpen.pensize(3)
bpen.pendown()

for side in range(4):
    bpen.fd(600)
    bpen.lt(90)
gamestate=1

player1health=3
player1health_pen = turtle.Turtle()
player1health_pen.color("white")
player1health_pen.speed(0)
player1health_pen.penup()
player1health_pen.hideturtle()
player1health_pen.setposition(-290, 280)
player1healthstring = "Player 1: %s" %(player1health)
player1health_pen.write(player1healthstring)

player1score=-10
player1score_pen = turtle.Turtle()
player1score_pen.color("white")
player1score_pen.speed(0)
player1score_pen.penup()
player1score_pen.hideturtle()
player1score_pen.setposition(-220, 280)
player1scorestring = "%s" %(player1score)
player1score_pen.write(player1scorestring)


player2health=3
player2health_pen = turtle.Turtle()
player2health_pen.color("white")
player2health_pen.speed(0)
player2health_pen.penup()
player2health_pen.hideturtle()
player2health_pen.setposition(162, 280)
player2healthstring = "Player 2: %s" %(player2health)
player2health_pen.write(player2healthstring)

player2score=0
player2score_pen = turtle.Turtle()
player2score_pen.color("white")
player2score_pen.speed(0)
player2score_pen.penup()
player2score_pen.hideturtle()
player2score_pen.setposition(232, 280)
player2scorestring = " %s" %(player2score)
player2score_pen.write(player2scorestring)
    
player1 = turtle.Turtle()
player1.color("blue")
player1.shape("triangle")
player1.speed(0)
player1.penup()
player1.setposition(-280,0 )
player1speed = 20


    
player2 = turtle.Turtle()
player2.color("red")
player2.shape("triangle")
player2.speed(0)
player2.penup()
player2.setposition(280,0 )
player2.lt(180)
player2speed = 20


number_of_enemies1 = 14
enemies1 = []
for i in range(number_of_enemies1):
    enemies1.append(turtle.Turtle())
for enemy in enemies1:  
    #Create the enemy
    enemy.color("green")
    enemy.shape("square")
    enemy.shapesize(1,1)
    enemy.penup()
    enemy.speed(0)
    x = random.randint(-250,250)
    y = random.randint(-250, 250)
    enemy.setposition(x, y)
    enemy.speed(50)
enemyspeed=4
    


bullet1 = turtle.Turtle()
bullet1.color("yellow")
bullet1.speed(0)
bullet1.penup()
bullet1.hideturtle()
bullet1.setposition(player1.xcor(), player1.ycor()  )
bullet1state="ready"
bullet1speed=80


bullet2 = turtle.Turtle()
bullet2.color("purple")
bullet2.speed(0)
bullet2.penup()
bullet2.hideturtle()
bullet2.setposition(player1.xcor()-15, player1.ycor()  )
bullet2.lt(180)
bullet2state="hazir"
bullet2speed=80

def player1up():
    y = player1.ycor()
    y += player1speed
    if (y > 280):
        y = 280
    player1.sety(y)
def player1down():
    y = player1.ycor()
    y -= player1speed
    if (y < -280):
        y = -280
    player1.sety(y)
def player1shoot():
    global bullet1state
    if (bullet1state == "ready"):
        winsound.PlaySound('sfx_wpn_laser6',winsound.SND_FILENAME)
        bullet1state = "fire"
        x = player1.xcor()+15
        y = player1.ycor() 
        bullet1.setposition(x, y)
        bullet1.showturtle()
    
def player2up():
    y = player2.ycor()
    y += player2speed
    if (y > 280):
        y = 280
    player2.sety(y)
def player2down():
    y = player2.ycor()
    y -= player2speed
    if (y < -280):
        y = -280
    player2.sety(y)
def player2shoot():
    global bullet2state
    if (bullet2state == "hazir"):
        winsound.PlaySound('sfx_wpn_laser6',winsound.SND_FILENAME)
        bullet2state = "ates"
        x = player2.xcor()-15
        y = player2.ycor()
        bullet2.setposition(x, y)
        bullet2.showturtle()
def collision(t1, t2):
    distance = math.sqrt(math.pow(t1.xcor()-t2.xcor(),2)+math.pow(t1.ycor()-t2.ycor(),2))
    if (distance < 60):
        return True
    else: 
        return False
    
wn.listen()
wn.onkey(player1up,"w")
wn.onkey(player1down,"s")
wn.onkey(player1shoot,"d")
wn.onkey(player2up,"Up")
wn.onkey(player2down,"Down")
wn.onkey(player2shoot,"Left")
while (gamestate==1): 
    x = bullet1.xcor()
    x += bullet1speed
    bullet1.setx(x)
    
    #border check bullet
    if (bullet1.xcor() > 285):
        bullet1.hideturtle()
        bullet1state = "ready"
   
   
    a = bullet2.xcor()
    a -= bullet2speed
    bullet2.setx(a)
    
    #border check bullet
    if (bullet2.xcor() < -285):
        bullet2.hideturtle()
        bullet2state = "hazir"
    
    
    for enemy in enemies1:

        #move the enemy
        y = enemy.ycor()
        y += enemyspeed
        enemy.sety(y)
        
        #reverse enemy
        if (enemy.ycor() > 280):
            for e in enemies1:
                
                x = random.randint(-200,200)
                e.setx(x)
            enemyspeed *= -1
            
        if (enemy.ycor() < -280):
            for e in enemies1:
                
                x = random.randint(-100,100)
                e.setx(x)
            enemyspeed *= -1
       
        if (collision(bullet1, enemy)):
            winsound.PlaySound('sfx_sounds_high1',winsound.SND_FILENAME)
            bullet1.hideturtle()
            bullet1state = "ready"
            bullet1.setposition(0,-400)
            x = 0
            y = random.randint(180, 250)
            enemy.setposition(x, y)
            player1score += 10
            player1scorestring = " %s" %(player1score)
            player1score_pen.clear()
            player1score_pen.write(player1scorestring )
    
        if (collision(bullet2, enemy)):
            winsound.PlaySound('sfx_sounds_high1',winsound.SND_FILENAME)
            bullet2.hideturtle()
            bulletstate = "hazir"
            bullet2.setposition(0,-400 )
            x = 0
            y = random.randint(180, 250)
            enemy.setposition(x, y)
            player2score += 10
            player2scorestring = " %s" %(player2score)
            player2score_pen.clear()
            player2score_pen.write(player2scorestring )

    if(collision(bullet2,player1)):
            winsound.PlaySound('sfx_damage_hit1',winsound.SND_FILENAME)
            bullet2.setposition(0,-400 )
            bullet2.hideturtle()
            bullet2state = "hazir"
            player1health =player1health-1
            player1healthstring="Player 1:%s" %player1health
            player1health_pen.clear()
            player1health_pen.write(player1healthstring)
    if(collision(bullet1,player2)):
            winsound.PlaySound('sfx_damage_hit1',winsound.SND_FILENAME)
            bullet1.setposition(0,-400)
            bullet1.hideturtle()
            bullet1state = "ready"
            player2health=player2health-1
            player2healthstring="Player 2:%s" %player2health
            player2health_pen.clear()
            player2health_pen.write(player2healthstring)
    if(player2health==0 or player1score==10000):
        print("Halycon is safe again")
        break
    if(player1health==0 or player2score==10000):
        print("Alliance has lost the Halycon.All hail Eridians!")
        break

       

